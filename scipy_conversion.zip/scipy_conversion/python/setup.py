from setuptools import setup
from Cython.Build import cythonize

setup(
  name = '_peak_finding_utilsclear',
  ext_modules = cythonize("_peak_finding_utils.pyx",annotate=True),
)