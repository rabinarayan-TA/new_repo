#include <iostream>
#include <iterator>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm> // for std::copy#include <iostream>
#include <iterator>
#include <fstream>
#include <vector>
#include <algorithm> // for std::copy
#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <cmath>
#include <string>
#include <map>
using namespace std;
std::vector<float> read_file(std::string input_path = "electrocardiogram.txt")
{
          std::ifstream input_file(input_path);
          std::istream_iterator<float> start(input_file), end;
          std::vector<float> numbers(start, end);
          if (input_file)
          {
                    float value;
                    while (input_file >> value)
                    {
                              numbers.push_back(value);
                    }
          }
          return numbers;
}
int main()
{
          std::vector<float> arr = read_file();
          cout << std::accumulate(arr.begin(), arr.end(), 0);
}