#include <iostream>
#include <iterator>
#include <fstream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <cmath>
#include <string>
#include <map>
#include <sstream>
using namespace std;

std::vector<float> read_file(std::string input_path = "electrocardiogram.txt")
{
    ifstream input_file(input_path);
    istream_iterator<float> start(input_file), end;
    vector<float> numbers(start, end);
    if (input_file)
    {
        float value;
        while (input_file >> value)
        {
            numbers.push_back(value);
        }
    }
    return numbers;
}
template <typename T>
vector<int> argsort(const vector<T> &array)
{
    vector<int> indices(array.size());
    iota(indices.begin(), indices.end(), 0);
    sort(indices.begin(), indices.end(),
         [&array](int left, int right) -> bool
         {
             // sort indices according to corresponding array element
             return array[left] < array[right];
         });

    return indices;
}
template <typename T>
vector<float> slice_by_index(const vector<T> array, const vector<int> index)
{

    vector<float> filtered_array(index.size());
    int counter = 0;
    for (auto &it : index)
    {

        filtered_array[counter] = array[it];
        counter++;
    }
    return filtered_array;
}
template <typename T>
vector<T> slice_by_bool(vector<T> arr, const vector<bool> bool_arr)
{
    arr.erase(std::remove_if(arr.begin(), arr.end(), [&bool_arr, &arr](auto const &i)
                             { return bool_arr.at(&i - arr.data()); }),
              arr.end());
    return arr;
}
template <typename K, typename V>
map<K, V> update_map(map<K, V> &m,
                     initializer_list<typename map<K, V>::value_type> l)
{
    for (const auto &p : l)
        m[p.first] = p.second;
    return m;
}
vector<int> _local_maxima_1d(vector<float> x)
{
    // Preallocate, there can't be more maxima than half the size of `x`
    vector<int> midpoints(x.size() / 2);
    vector<int> left_edges(x.size() / 2);
    vector<int> right_edges(x.size() / 2);
    int m = 0; // Pointer to the end of valid area in allocated arrays

    int i = 1;                // Pointer to current sample, first one can't be maxima
    int i_max = x.size() - 1; // Last sample can't be maxima
    while (i < i_max)
    {
        // Test if previous sample is smaller
        if (x[i - 1] < x[i])
        {
            int i_ahead = i + 1; // Index to look ahead of current sample

            // Find next sample that is unequal to x[i]
            while ((i_ahead < i_max) && (x[i_ahead] == x[i]))
            {
                i_ahead++;
            }

            // Maxima is found if next unequal sample is smaller than x[i]
            if (x[i_ahead] < x[i])
            {
                left_edges[m] = i;
                right_edges[m] = i_ahead - 1;
                midpoints[m] = (left_edges[m] + right_edges[m]) / 2;
                m++;
                // Skip samples that can't be maximum
                i = i_ahead;
            }
        }
        i++;
    }
    return midpoints;
}
vector<bool> _select_by_peak_distance(vector<int> peaks, vector<float> priority, float distance)
{
    const int peaks_size = peaks.size();
    // Round up because actual peak distance can only be natural number
    const int distance_ = ceil(distance);
    vector<bool> keep(peaks.size(), true); // Prepare array of flags

    // Create map from `i` (index for `peaks` sorted by `priority`) to `j` (index
    // for `peaks` sorted by position). This allows to iterate `peaks` and `keep`
    // with `j` by order of `priority` while still maintaining the ability to
    // step to neighbouring peaks with (`j` + 1) or (`j` - 1).
    std::vector<int> priority_to_position = argsort(priority);

    // Highest priority first -> iterate in reverse order (decreasing)
    for (int i = peaks.size() - 1; i >= 0; --i)
    {
        // "Translate" `i` to `j` which points to current peak whose
        // neighbours are to be evaluated
        int j = priority_to_position[i];
        if (!keep[j])
        {
            // Skip evaluation for peak already marked as "don't keep"
            continue;
        }

        int k = j - 1;
        // Flag "earlier" peaks for removal until minimal distance is exceeded
        while (k >= 0 && peaks[j] - peaks[k] < distance_)
        {
            keep[k] = false;
            --k;
        }

        k = j + 1;
        // Flag "later" peaks for removal until minimal distance is exceeded
        while (k < peaks.size() && peaks[k] - peaks[j] < distance_)
        {
            keep[k] = false;
            ++k;
        }
    }
    return keep;
}

vector<float> _peak_prominences(const vector<float> x,
                                const vector<int> peaks,
                                int wlen)
{

    std::vector<float> prominences;
    std::vector<int> left_bases;
    std::vector<int> right_bases;
    int peak_nr, peak, i_min, i_max, i;
    float left_min, right_min;
    bool show_warning = false;
    prominences.resize(peaks.size());
    left_bases.resize(peaks.size());
    right_bases.resize(peaks.size());
    for (peak_nr = 0; peak_nr < peaks.size(); peak_nr++)
    {
        peak = peaks[peak_nr];
        i_min = 0;
        i_max = x.size() - 1;
        if (!(i_min <= peak && peak <= i_max))
        {
            throw invalid_argument("peak " + to_string(peak) +
                                   " is not a valid index for `x`");
        }
        if (2 <= wlen)
        {
            // Adjust window around the evaluated peak (within bounds);
            // if wlen is even the resulting window length is is implicitly
            // rounded to next odd integer
            i_min = max(peak - wlen / 2, i_min);
            i_max = min(peak + wlen / 2, i_max);
        }
        // Find the left base in interval [i_min, peak]
        i = left_bases[peak_nr] = peak;
        left_min = x[peak];
        while (i_min <= i && x[i] <= x[peak])
        {
            if (x[i] < left_min)
            {
                left_min = x[i];
                left_bases[peak_nr] = i;
            }
            i -= 1;
        }
        // Find the right base in interval [peak, i_max]
        i = right_bases[peak_nr] = peak;
        right_min = x[peak];
        while (i <= i_max && x[i] <= x[peak])
        {
            if (x[i] < right_min)
            {
                right_min = x[i];
                right_bases[peak_nr] = i;
            }
            i += 1;
        }
        prominences[peak_nr] = x[peak] - max(left_min, right_min);
        if (prominences[peak_nr] == 0)
        {
            show_warning = true;
        }
    }
    if (show_warning)
    {
        cout << "some peaks have a prominence of 0" << endl;
    }
    return prominences;
}
vector<float> _peak_widths(const vector<float> x,
                           const vector<int> peaks,
                           double rel_height,
                           const vector<float> prominences,
                           const vector<int> left_bases,
                           const vector<int> right_bases)
{
    vector<float> widths, width_heights;
    vector<float> left_ips, right_ips;
    int peak_nr, peak, i_min, i_max, i;
    float height, left_ip, right_ip;
    bool show_warning = false;
    widths.resize(peaks.size());
    width_heights.resize(peaks.size());
    left_ips.resize(peaks.size());
    right_ips.resize(peaks.size());
    if (rel_height < 0)
    {
        throw invalid_argument("`rel_height` must be greater or equal to 0.0");
    }
    if (!(peaks.size() == prominences.size() &&
          prominences.size() == left_bases.size() &&
          left_bases.size() == right_bases.size()))
    {
        throw invalid_argument("arrays in `prominence_data` must have the same shape as `peaks`");
    }
    for (peak_nr = 0; peak_nr < peaks.size(); peak_nr++)
    {
        i_min = left_bases[peak_nr];
        i_max = right_bases[peak_nr];
        peak = peaks[peak_nr];
        // Validate bounds and order
        if (!(0 <= i_min && i_min <= peak && peak <= i_max && i_max < x.size()))
        {
            throw invalid_argument("prominence data is invalid for peak " + to_string(peak));
        }
        height = width_heights[peak_nr] = x[peak] - prominences[peak_nr] * rel_height;
        // Find intersection point on left side
        i = peak;
        while (i_min < i && height < x[i])
        {
            i -= 1;
        }
        left_ip = i;
        if (x[i] < height)
        {
            // Interpolate if true intersection height is between samples
            left_ip += (height - x[i]) / (x[i + 1] - x[i]);
        }
        // Find intersection point on right side
        i = peak;
        while (i < i_max && height < x[i])
        {
            i += 1;
        }
        right_ip = i;
        if (x[i] < height)
        {
            // Interpolate if true intersection height is between samples
            right_ip -= (height - x[i]) / (x[i - 1] - x[i]);
        }
        widths[peak_nr] = right_ip - left_ip;
        if (widths[peak_nr] == 0)
        {
            show_warning = true;
        }
        left_ips[peak_nr] = left_ip;
        right_ips[peak_nr] = right_ip;
    }
    if (show_warning)
    {
        cout << "some peaks have a width of 0" << endl;
    }
    return widths;
}
template <typename T>
vector<int> find_peaks(vector<float> x, T dist = NULL, T prominence = NULL, T rel_height = 0.5)
{
    vector<int> peaks, left_edges, right_edges;
    // map<string, > properties;
    vector<double> prominences;
    vector<double> left_bases;
    vector<double> right_bases;

    peaks, left_edges, right_edges = _local_maxima_1d(x);
    cout << dist;
    if (dist != NULL)
    {
        cout << "x";
        // Evaluate distance condition
        vector<bool> keep = _select_by_peak_distance(peaks, slice_by_index(x, peaks), dist);
        for (int i = 0; i < keep.size(); i++)
        {
            cout << keep[i] << " ";
        }
        peaks = slice_by_bool(peaks, keep);
        // for (iter = properties.begin(); iter != properties.end(); iter++)
        // {
        //     properties[(*iter).first] = slice_by_bool(properties[(*iter).second], keep);
        // }
    }

    // if (prominence != NULL)
    // {
    //     // Calculate prominence (required for both conditions)
    //     wlen = _arg_wlen_as_expected(wlen)
    //         prominences,
    //     left_bases, right_bases = _peak_prominences(x, peaks, wlen = wlen) update_map(properties, {{'prominences', prominences}, {'left_bases', left_bases}, {'right_bases', right_bases}});
    //     // Evaluate prominence condition
    //     pmin, pmax = _unpack_condition_args(prominence, x, peaks);
    //     keep = _select_by_property(properties['prominences'], pmin, pmax)
    //         peaks = slice_by_bool(peaks, keep);
    //     for (iter = properties.begin(); iter != properties.end(); iter++)
    //     {
    //         properties[(*iter).first] = slice_by_bool(properties[(*iter).second], keep);
    //     }
    // }

    return peaks;
}
int main()
{
    vector<float> arr = read_file();
    vector<int> xy = find_peaks(arr, 5);
    // vector<bool> ch = _select_by_peak_distance(xy, slice_by_index(arr, xy), 5555);

    for (int i = 0; i < xy.size(); i++)
    {
        cout << xy[i] << "\n";
    };
}