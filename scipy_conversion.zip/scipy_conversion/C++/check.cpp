#include <iostream>
#include <numeric>
#include <iterator>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm> // for std::copy#include <iostream>
#include <iterator>
#include <fstream>
#include <vector>
#include <algorithm> // for std::copy
using namespace std;
std::vector<std::vector<int>> read_file(std::istream &input)
{
          std::vector<float> lines;

          std::string line;
          while (std::getline(input, line))
          {
                    std::istringstream line_stream(line);

                    lines.emplace_back(std::istream_iterator<int>(line_stream),
                                       std::istream_iterator<int>());
          }

          return lines;
}
int main()
{
          std::ifstream input("electrocardiogram.txt");
          auto data = read_file(input);
          cout << std::accumulate(data.begin(), data.end(), 0) << ",";
          std::cout << "First line of data: ";
          for (auto value : data[0])
          {
                    std::cout << value << ' ';
          }
          std::cout << '\n';

          std::cout << "Second line of data: ";
          for (auto value : data[1])
          {
                    std::cout << value << ' ';
          }
          std::cout << '\n';
}