#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <cmath>
#include <string>
#include <map>
using namespace std;
template <typename T>
vector<int> argsort(const vector<T> &array)
{
          vector<int> indices(array.size());
          iota(indices.begin(), indices.end(), 0);
          sort(indices.begin(), indices.end(),
               [&array](int left, int right) -> bool
               {
                         // sort indices according to corresponding array element
                         return array[left] < array[right];
               });

          return indices;
}
template <typename T>
vector<double> slice_by_index(const vector<T> array, const vector<int> index)
{

          vector<float> filtered_array(index.size());
          int counter = 0;
          for (auto &it : index)
          {

                    filtered_array[counter] = array[it];
                    counter++;
          }
          return filtered_array;
}
template <typename T>
vector<T> slice_by_bool(const vector<T> arr, const vector<bool> bool_arr)
{
          arr.erase(std::remove_if(arr.begin(), arr.end(), [&bool_arr, &arr](auto const &i)
                                   { return bool_arr.at(&i - arr.data()); }),
                    arr.end());
          return arr;
}
template <typename K, typename V>
map<K, V> update_map(map<K, V> &m,
                     initializer_list<typename map<K, V>::value_type> l)
{
          for (const auto &p : l)
                    m[p.first] = p.second;
          return m;
}
